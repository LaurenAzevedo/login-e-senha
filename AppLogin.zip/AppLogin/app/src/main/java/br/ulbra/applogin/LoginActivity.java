package br.ulbra.applogin;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {


    EditText edtInsiraLogin, edtInsiraSenha;
    Button btnAtentica, btnVoltarPrincipal;
    DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.autenticacao);
        db = new DBHelper(this);
        edtInsiraLogin = (EditText) findViewById(R.id.edtInsiraLogin);
        edtInsiraSenha = (EditText) findViewById(R.id.edtInsiraSenha);
        btnAtentica = (Button) findViewById(R.id.btnEntrarAutentic);

        btnVoltarPrincipal = (Button) findViewById(R.id.btnVoltarPrincipal);

        btnVoltarPrincipal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(LoginActivity.this, MainActivity.class);
                startActivity(i);
            }
        });

        btnAtentica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String username = edtInsiraLogin.getText().toString();
                String password = edtInsiraSenha.getText().toString();
                if (username.equals("")) {
                    Toast.makeText(LoginActivity.this, "Usuario não inserido, tente novamente", Toast.LENGTH_SHORT).show();
                } else if (password.equals("")) {
                    Toast.makeText(LoginActivity.this, "Senha não inserida, tente novamente", Toast.LENGTH_SHORT).show();
                } else {
                    String res = db.validarLogin(username, password);
                    if (res.equals("OK")) {
                        Toast.makeText(LoginActivity.this, "Login confirmado com sucesso!", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(LoginActivity.this, "Seu login ou senha está errado!", Toast.LENGTH_SHORT).show();
                    }
                }
            }


        });


    }
}
